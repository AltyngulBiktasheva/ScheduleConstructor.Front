import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const GroupsPage: React.FC = () => (
  <PlaceholderPage
    title="Академические группы"
    description="Управление потоками, группами и подгруппами."
    icon="🎓"
  />
);
