import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const StudentSchedulePage: React.FC = () => (
  <PlaceholderPage
    title="Расписание для студентов"
    description="Выберите группу для просмотра расписания."
    icon="🎒"
  />
);
