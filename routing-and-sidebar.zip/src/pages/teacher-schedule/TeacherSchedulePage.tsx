import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const TeacherSchedulePage: React.FC = () => (
  <PlaceholderPage
    title="Моё расписание"
    description="Просмотр расписания занятий для выбранного преподавателя."
    icon="📅"
  />
);
