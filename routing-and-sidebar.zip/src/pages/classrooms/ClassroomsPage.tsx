import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const ClassroomsPage: React.FC = () => (
  <PlaceholderPage
    title="Аудитории"
    description="Список аудиторий по корпусам, создание и редактирование."
    icon="🏫"
  />
);
