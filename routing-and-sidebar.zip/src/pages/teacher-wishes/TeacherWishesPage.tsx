import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const TeacherWishesPage: React.FC = () => (
  <PlaceholderPage
    title="Мои пожелания"
    description="Желаемое и запрещённое время, аудитории и дополнительные комментарии."
    icon="💬"
  />
);
