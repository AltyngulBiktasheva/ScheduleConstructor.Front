import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const DisciplinesPage: React.FC = () => (
  <PlaceholderPage
    title="Дисциплины"
    description="Список всех дисциплин, добавление, редактирование и удаление."
    icon="📚"
  />
);
