import React from 'react';
import { PlaceholderPage } from '../../components/PlaceholderPage/PlaceholderPage';

export const TeachersPage: React.FC = () => (
  <PlaceholderPage
    title="Преподаватели"
    description="Список преподавателей, их пожелания и управление данными."
    icon="👨‍🏫"
  />
);
