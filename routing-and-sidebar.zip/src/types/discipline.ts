import type { BuildingType } from '../constants/buildings';

export type RepeatType = 'every-week' | 'once' | 'every-two-weeks' | 'custom';

export interface WeeklyOccurrence {
  dayId: string;
  timeStart: string;
  timeEnd: string;
}

export interface Discipline {
  id: string;
  name: string;
  teacher?: string;
  building: BuildingType;
  buildingName?: string;
  audience?: string;
  repeat: RepeatType;
  comment?: string;
  isInGrid: boolean;
  isStatic?: boolean;
  canOverlap?: boolean;
  occurrences?: WeeklyOccurrence[];
  // For single-occurrence disciplines placed in grid
  slotId?: string;
  dayId?: string;
  timeStart?: string;
  timeEnd?: string;
  highlightSlots?: boolean;
}

export interface DisciplinePosition {
  disciplineId: string;
  dayId: string;
  timeStart: string;
  timeEnd: string;
  column?: number;
  totalColumns?: number;
}
